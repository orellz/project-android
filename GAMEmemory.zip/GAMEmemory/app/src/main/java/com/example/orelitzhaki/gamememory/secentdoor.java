package com.example.orelitzhaki.gamememory;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.View;

import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;


public class secentdoor extends Activity {

    TextView tv_p1 ;

    ImageView Bcard, Bcard1, Bcard2, Bcard3, Bcarda, Bcard1a, Bcard2a, Bcard3a,
            Bcardb, Bcard1b, Bcard2b, Bcard3b, Bcardc, Bcard1c, Bcard2c, Bcard3c;

    Integer[] cardarray = {101, 102, 103, 104, 105, 106, 107, 108, 201, 202, 203, 204, 205, 206, 207, 208};


    int imagescard1, imagescard1a, imagescard2, imagescard2a, imagescard3, imagescard3a, imagescard4, imagescard4a,
            imagescard5, imagescard5a, imagescard6, imagescard6a, imagescard7,
            imagescard7a, imagescard8, imagescard8a;

    int firstcard, secentcard;
    int clickfitrt, clicksecent;
    int cardNumber = 1;

    int turn = 1;
    int playerpoints = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secentdoor);



        tv_p1 = (TextView) findViewById(R.id.tvp1);



        Bcard = (ImageView) findViewById(R.id.Bcard);
        Bcard1 = (ImageView) findViewById(R.id.Bcard1);
        Bcard2 = (ImageView) findViewById(R.id.Bcard2);
        Bcard3 = (ImageView) findViewById(R.id.Bcard3);
        Bcarda = (ImageView) findViewById(R.id.Bcarda);
        Bcard1a = (ImageView) findViewById(R.id.Bcard1a);
        Bcard2a = (ImageView) findViewById(R.id.Bcard2a);
        Bcard3a = (ImageView) findViewById(R.id.Bcard3a);
        Bcardb = (ImageView) findViewById(R.id.Bcardb);
        Bcard1b = (ImageView) findViewById(R.id.Bcard1b);
        Bcard2b = (ImageView) findViewById(R.id.Bcard2b);
        Bcard3b = (ImageView) findViewById(R.id.Bcard3b);
        Bcardc = (ImageView) findViewById(R.id.Bcardc);
        Bcard1c = (ImageView) findViewById(R.id.Bcard1c);
        Bcard2c = (ImageView) findViewById(R.id.Bcard2c);
        Bcard3c = (ImageView) findViewById(R.id.Bcard3c);


        Bcard.setTag("0");
        Bcard1.setTag("1");
        Bcard2.setTag("2");
        Bcard3.setTag("3");
        Bcarda.setTag("4");
        Bcard1a.setTag("5");
        Bcard2a.setTag("6");
        Bcard3a.setTag("7");
        Bcardb.setTag("8");
        Bcard1b.setTag("9");
        Bcard2b.setTag("10");
        Bcard3b.setTag("11");
        Bcardc.setTag("12");
        Bcard1c.setTag("13");
        Bcard2c.setTag("14");
        Bcard3c.setTag("15");
        frontofcard();

        Collections.shuffle(Arrays.asList(cardarray));



        Bcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard, thecard);
            }
        });

        Bcard1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard1, thecard);
            }
        });


        Bcard2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard2, thecard);
            }
        });

        Bcard3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard3, thecard);
            }
        });

        Bcarda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcarda, thecard);
            }
        });

        Bcard1a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard1a, thecard);
            }
        });


        Bcard2a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard2a, thecard);
            }
        });

        Bcard3a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard3a, thecard);
            }
        });


        Bcardb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcardb, thecard);
            }
        });

        Bcard1b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard1b, thecard);
            }
        });


        Bcard2b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard2b, thecard);
            }
        });

        Bcard3b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard3b, thecard);
            }
        });


        Bcardc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcardc, thecard);
            }
        });

        Bcard1c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard1c, thecard);
            }
        });


        Bcard2c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard2c, thecard);
            }
        });

        Bcard3c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thecard = Integer.parseInt((String) v.getTag());
                dostuff(Bcard3c, thecard);
            }
        });


    }


    private void dostuff(ImageView xx, int card) {
        if (cardarray[card] == 101) {
            xx.setImageResource(imagescard1);
        } else if (cardarray[card] == 201) {
            xx.setImageResource(imagescard1a);
        } else if (cardarray[card] == 102) {
            xx.setImageResource(imagescard2);
        } else if (cardarray[card] == 202) {
            xx.setImageResource(imagescard2a);
        } else if (cardarray[card] == 103) {
            xx.setImageResource(imagescard3);
        } else if (cardarray[card] == 203) {
            xx.setImageResource(imagescard3a);
        } else if (cardarray[card] == 104) {
            xx.setImageResource(imagescard4);
        } else if (cardarray[card] == 204) {
            xx.setImageResource(imagescard4a);
        } else if (cardarray[card] == 105) {
            xx.setImageResource(imagescard5);
        } else if (cardarray[card] == 205) {
            xx.setImageResource(imagescard5a);
        } else if (cardarray[card] == 106) {
            xx.setImageResource(imagescard6);
        } else if (cardarray[card] == 206) {
            xx.setImageResource(imagescard6a);
        } else if (cardarray[card] == 107) {
            xx.setImageResource(imagescard7);
        } else if (cardarray[card] == 207) {
            xx.setImageResource(imagescard7a);
        } else if (cardarray[card] == 108) {
            xx.setImageResource(imagescard8);
        } else if (cardarray[card] == 208) {
            xx.setImageResource(imagescard8a);
        }

        if (cardNumber == 1) {
            firstcard = cardarray[card];
            if (firstcard > 200) {
                firstcard = firstcard - 100;
            }
            cardNumber = 2;
            clickfitrt = card;

            xx.setEnabled(false);

        } else if (cardNumber == 2) {
            secentcard = cardarray[card];
            if (secentcard > 200) {
                secentcard = secentcard - 100;
            }
            cardNumber = 1;
            clicksecent = card;

            Bcard.setEnabled(false);
            Bcard1.setEnabled(false);
            Bcard2.setEnabled(false);
            Bcard3.setEnabled(false);
            Bcarda.setEnabled(false);
            Bcard1a.setEnabled(false);
            Bcard2a.setEnabled(false);
            Bcard3a.setEnabled(false);
            Bcardb.setEnabled(false);
            Bcard1b.setEnabled(false);
            Bcard2b.setEnabled(false);
            Bcard3b.setEnabled(false);
            Bcardc.setEnabled(false);
            Bcard1c.setEnabled(false);
            Bcard2c.setEnabled(false);
            Bcard3c.setEnabled(false);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    calculate();
                }
            }, 1000);
        }

    }


    private void calculate() {
        if (firstcard == secentcard) {
            if (clickfitrt == 0) {
                Bcard.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 1) {
                Bcard1.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 2) {
                Bcard2.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 3) {
                Bcard3.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 4) {
                Bcarda.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 5) {
                Bcard1a.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 6) {
                Bcard2a.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 7) {
                Bcard3a.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 8) {
                Bcardb.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 9) {
                Bcard1b.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 10) {
                Bcard2b.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 11) {
                Bcard3b.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 12) {
                Bcardc.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 13) {
                Bcard1c.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 14) {
                Bcard2c.setVisibility(View.INVISIBLE);
            } else if (clickfitrt == 15) {
                Bcard3c.setVisibility(View.INVISIBLE);
            }

            if (clicksecent == 0) {
                Bcard.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 1) {
                Bcard1.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 2) {
                Bcard2.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 3) {
                Bcard3.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 4) {
                Bcarda.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 5) {
                Bcard1a.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 6) {
                Bcard2a.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 7) {
                Bcard3a.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 8) {
                Bcardb.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 9) {
                Bcard1b.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 10) {
                Bcard2b.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 11) {
                Bcard3b.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 12) {
                Bcardc.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 13) {
                Bcard1c.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 14) {
                Bcard2c.setVisibility(View.INVISIBLE);
            } else if (clicksecent == 15) {
                Bcard3c.setVisibility(View.INVISIBLE);
            }

            if (turn == 1) {
                playerpoints++;
                tv_p1.setText("player_1:" + playerpoints);
                MediaPlayer successsoud = MediaPlayer.create(this,R.raw.successsoud);
               successsoud.start();
            } else if (turn == 2) {
                playerpoints++;
                tv_p1.setText("player_1:" + playerpoints);
                MediaPlayer successsoud = MediaPlayer.create(this,R.raw.successsoud);
                successsoud.start();

            }
        } else {
            MediaPlayer fail = MediaPlayer.create(this,R.raw.fail);
            fail.start();
            Bcard.setImageResource(R.drawable.card);
            Bcard1.setImageResource(R.drawable.card);
            Bcard2.setImageResource(R.drawable.card);
            Bcard3.setImageResource(R.drawable.card);
            Bcarda.setImageResource(R.drawable.card);
            Bcard1a.setImageResource(R.drawable.card);
            Bcard2a.setImageResource(R.drawable.card);
            Bcard3a.setImageResource(R.drawable.card);
            Bcardb.setImageResource(R.drawable.card);
            Bcard1b.setImageResource(R.drawable.card);
            Bcard2b.setImageResource(R.drawable.card);
            Bcard3b.setImageResource(R.drawable.card);
            Bcardc.setImageResource(R.drawable.card);
            Bcard1c.setImageResource(R.drawable.card);
            Bcard2c.setImageResource(R.drawable.card);
            Bcard3c.setImageResource(R.drawable.card);

            if (turn == 1) {
                turn = 2;
            } else if (turn == 2) {
                turn = 1;
            }
        }

        Bcard.setEnabled(true);
        Bcard1.setEnabled(true);
        Bcard2.setEnabled(true);
        Bcard3.setEnabled(true);
        Bcarda.setEnabled(true);
        Bcard1a.setEnabled(true);
        Bcard2a.setEnabled(true);
        Bcard3a.setEnabled(true);
        Bcardb.setEnabled(true);
        Bcard1b.setEnabled(true);
        Bcard2b.setEnabled(true);
        Bcard3b.setEnabled(true);
        Bcardc.setEnabled(true);
        Bcard1c.setEnabled(true);
        Bcard2c.setEnabled(true);
        Bcard3c.setEnabled(true);



        checkend();

    }

    private void checkend() {
        if (Bcard.getVisibility() == View.INVISIBLE &&
                Bcard1.getVisibility() == View.INVISIBLE &&
                Bcard2.getVisibility() == View.INVISIBLE &&
                Bcard3.getVisibility() == View.INVISIBLE &&
                Bcarda.getVisibility() == View.INVISIBLE &&
                Bcard1a.getVisibility() == View.INVISIBLE &&
                Bcard2a.getVisibility() == View.INVISIBLE &&
                Bcard3a.getVisibility() == View.INVISIBLE &&
                Bcardb.getVisibility() == View.INVISIBLE &&
                Bcard1b.getVisibility() == View.INVISIBLE &&
                Bcard2b.getVisibility() == View.INVISIBLE &&
                Bcard3b.getVisibility() == View.INVISIBLE &&
                Bcardc.getVisibility() == View.INVISIBLE &&
                Bcard1c.getVisibility() == View.INVISIBLE &&
                Bcard2c.getVisibility() == View.INVISIBLE &&
                Bcard3c.getVisibility() == View.INVISIBLE) {



            AlertDialog.Builder ADB = new AlertDialog.Builder(secentdoor.this);
            MediaPlayer victory = MediaPlayer.create(this,R.raw.victory);
            victory.start();
            ADB.setMessage("GAME OVER! \n p1: " + playerpoints)

                    .setCancelable(false)
                    .setPositiveButton("NEW", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(getApplicationContext(), secentdoor.class);
                            startActivity(intent);
                            finish();
                        }
                    })
                    .setNegativeButton("EXIT", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
            AlertDialog alertDialog = ADB.create();
            alertDialog.show();


        }

    }

    private void frontofcard() {
        imagescard1 = R.drawable.one;
        imagescard1a = R.drawable.one1;
        imagescard2 = R.drawable.two;
        imagescard2a = R.drawable.two1;
        imagescard3 = R.drawable.three;
        imagescard3a = R.drawable.three1;
        imagescard4 = R.drawable.four;
        imagescard4a = R.drawable.four1;
        imagescard5 = R.drawable.five;
        imagescard5a = R.drawable.five1;
        imagescard6 = R.drawable.six;
        imagescard6a = R.drawable.six1;
        imagescard7 = R.drawable.seven;
        imagescard7a = R.drawable.seven;
        imagescard8 = R.drawable.twelve;
        imagescard8a = R.drawable.twelve1;
    }





}
