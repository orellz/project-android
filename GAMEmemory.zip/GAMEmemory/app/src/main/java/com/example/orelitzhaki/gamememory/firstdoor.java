package com.example.orelitzhaki.gamememory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class firstdoor extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstdoor);


    }


    public void StartNG(View view) {
        Intent intent = new Intent(firstdoor.this, secentdoor.class);
        startActivity(intent);

    }

}
